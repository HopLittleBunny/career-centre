---
title: Career Centre
---

# Career Centre

Career Centre is a free career decision plugin by Amit Sharma for ChatGPT and Claude. Share one CV or the key versions you use for different role directions, describe what matters, and use one continuing conversation to find roles worth your time, judge the real fit, create evidence-safe Word application packs and keep track of what happens next.

## Simple by design

1. Say “Help me find my next role.”
2. Share one CV or your key role-specific versions.
3. Answer only the few preferences the CV cannot supply.
4. Review a short, selective set of roles with exact links and salary context.
5. Create a Word CV and cover letter for the roles you choose.

Before the first search, Career Centre shows exactly what it will assume: market and work-right boundary, source mix, salary/currency, employment preference, CV length and section plan. Experienced candidates default to a two-page CV with the second page at least 80% filled; early-career candidates may use one strong page.

The skill first gives a qualitative CV review: what already works, what may be underselling the candidate and one priority edit. It does not pretend there is one universal ATS score. With multiple CVs, it identifies the best starting base by direction and flags material inconsistencies.

The defaults work for most people. Anyone who wants more control can change advanced preferences—including document language, regional spelling, fields and section order—in ordinary language or provide a reference Word CV to use as the visual model. Only the format is reused—the reference person's content and personal data are not.

There are no separate Career Centre accounts, commands, setup projects or publisher-operated CV database. The plugin uses the ChatGPT or Claude plan and product limits of the person who installs it.

The Career Passport is the portable Career Evidence File and history backup: source CVs, approved evidence, generated-document versions, preferences, corrections, role feedback and application outcomes. Keep one main Career Centre conversation and save the latest Passport because a separate new conversation may not inherit the earlier CV or history. Search feedback can improve preferences, but job descriptions never become evidence about the candidate.

If Word creation is unavailable, Career Centre returns the complete ready-to-copy CV in chat as a clearly labelled partial result rather than returning nothing.

## Honest boundaries

Career Centre does not invent evidence, guarantee interviews, auto-submit applications or send messages on a user's behalf. A role cannot be marked Apply without an exact open posting and enough evidence to support the decision.

- [Privacy](privacy.md)
- [Terms](terms.md)
- [Support](support.md)
- [Install](install.md)
